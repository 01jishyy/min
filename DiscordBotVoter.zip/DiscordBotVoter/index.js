// index.js - Full-featured safe Discord bot (slash + prefix + music + moderation + automation + dashboard)
// REQUIRED PACKAGES: discord.js@14 express pretty-ms node-fetch ms @discordjs/voice play-dl
// Setup: BOT_TOKEN, CLIENT_ID, OWNER_ID in environment (Replit Secrets); create /data/*.json files as documented.

const fs = require('fs');
const path = require('path');
const express = require('express');
const prettyMs = require('pretty-ms');
const fetch = require('node-fetch');
const playdl = require('play-dl'); // supports many sources
const { joinVoiceChannel, createAudioPlayer, createAudioResource, AudioPlayerStatus, getVoiceConnection } = require('@discordjs/voice');
const { Client, GatewayIntentBits, REST, Routes, SlashCommandBuilder, Partials, EmbedBuilder, PermissionsBitField } = require('discord.js');
require('dotenv').config();

// ---------- CONFIG ----------
const TOKEN = process.env.BOT_TOKEN;
const CLIENT_ID = process.env.CLIENT_ID;
const OWNER_ID = process.env.OWNER_ID;
const DASHBOARD_PASSWORD = "$$Wolvesmin1986$$"; // per your request

if (!TOKEN || !CLIENT_ID || !OWNER_ID) {
  console.error('Missing BOT_TOKEN, CLIENT_ID, or OWNER_ID in environment. Set them in Replit Secrets.');
  process.exit(1);
}

// ---------- DATA FILES ----------
const DATA_DIR = path.join(process.cwd(), 'data');
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR);

const FILES = {
  commands: path.join(DATA_DIR, 'commands.json'),
  allowed: path.join(DATA_DIR, 'allowed.json'),
  prefixes: path.join(DATA_DIR, 'prefixes.json'),
  economy: path.join(DATA_DIR, 'economy.json'),
  xp: path.join(DATA_DIR, 'xp.json'),
  commandsList: path.join(DATA_DIR, 'commandsList.json'),
  autoresponders: path.join(DATA_DIR, 'autoresponders.json'),
  aliases: path.join(DATA_DIR, 'aliases.json'),
  welcome: path.join(DATA_DIR, 'welcome.json'),
  starboard: path.join(DATA_DIR, 'starboard.json'),
  voice: path.join(DATA_DIR, 'voice.json'),
  snipe: path.join(DATA_DIR, 'snipe.json'),
  roles: path.join(DATA_DIR, 'roles.json'),
  logs: path.join(DATA_DIR, 'logs.json'),
  musicQueues: path.join(DATA_DIR, 'musicQueues.json')
};

function safeRead(file, fallback) {
  try {
    if (!fs.existsSync(file)) fs.writeFileSync(file, JSON.stringify(fallback ?? {}, null, 2));
    const raw = fs.readFileSync(file, 'utf8') || '{}';
    return JSON.parse(raw);
  } catch (e) {
    console.error('safeRead error', file, e);
    return fallback ?? {};
  }
}
function safeWrite(file, data) {
  try { fs.writeFileSync(file, JSON.stringify(data, null, 2)); }
  catch (e) { console.error('safeWrite error', file, e); }
}

// load stores
let customCommands = safeRead(FILES.commands, {});
let allowedArr = safeRead(FILES.allowed, [OWNER_ID]);
let allowedUsers = new Set(Array.isArray(allowedArr) ? allowedArr : [OWNER_ID]);
let prefixes = safeRead(FILES.prefixes, {});
let economy = safeRead(FILES.economy, {});
let xp = safeRead(FILES.xp, {});
let commandsList = safeRead(FILES.commandsList, {}); // categories JSON
let autoresponders = safeRead(FILES.autoresponders, {});
let aliases = safeRead(FILES.aliases, {});
let welcomeCfg = safeRead(FILES.welcome, {});
let starboardCfg = safeRead(FILES.starboard, {});
let voiceCfg = safeRead(FILES.voice, {});
let snipeStore = safeRead(FILES.snipe, {});
let roleBindings = safeRead(FILES.roles, {}); // guildId -> roleId allowed to moderate
let logChannels = safeRead(FILES.logs, {}); // guildId -> channelId
let musicQueues = safeRead(FILES.musicQueues, {}); // guildId -> { queue: [...], playing: false }

// helper to persist everything periodic
function saveAll() {
  safeWrite(FILES.commands, customCommands);
  safeWrite(FILES.allowed, [...allowedUsers]);
  safeWrite(FILES.prefixes, prefixes);
  safeWrite(FILES.economy, economy);
  safeWrite(FILES.xp, xp);
  safeWrite(FILES.commandsList, commandsList);
  safeWrite(FILES.autoresponders, autoresponders);
  safeWrite(FILES.aliases, aliases);
  safeWrite(FILES.welcome, welcomeCfg);
  safeWrite(FILES.starboard, starboardCfg);
  safeWrite(FILES.voice, voiceCfg);
  safeWrite(FILES.snipe, snipeStore);
  safeWrite(FILES.roles, roleBindings);
  safeWrite(FILES.logs, logChannels);
  safeWrite(FILES.musicQueues, musicQueues);
}

// ---------- KEEP-ALIVE + DASHBOARD ----------
const app = express();
app.use(express.urlencoded({ extended: true }));
app.get('/', (req, res) => {
  res.send('<h2>Bot is alive. Go to <a href="/dashboard">/dashboard</a> (password protected).</h2>');
});
app.get('/dashboard', (req, res) => {
  // simple password form
  res.send(`
    <html><body>
    <form method="POST" action="/dashboard">
      <label>Password: <input name="pw" type="password"/></label>
      <button type="submit">Login</button>
    </form></body></html>`);
});
app.post('/dashboard', (req, res) => {
  const pw = req.body.pw;
  if (pw !== DASHBOARD_PASSWORD) return res.status(401).send('Unauthorized');
  // show basic stats
  const guildCount = client.guilds.cache.size;
  const userCount = client.users.cache.size;
  const uptime = process.uptime();
  const commandsExecuted = Object.values(musicQueues).reduce((a,b)=>a+(b.playCount||0),0);
  res.send(`<h1>Dashboard</h1>
    <p>Guilds: ${guildCount}</p>
    <p>Users cached: ${userCount}</p>
    <p>Uptime: ${prettyMs(uptime*1000)}</p>
    <p>Music plays (approx): ${commandsExecuted}</p>
  `);
});
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Keep-alive & dashboard running on port ${PORT}`));

// ---------- DISCORD CLIENT ----------
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildMessageReactions,
    GatewayIntentBits.GuildVoiceStates,
    GatewayIntentBits.DirectMessages
  ],
  partials: [Partials.Channel, Partials.Message, Partials.Reaction]
});

const rest = new REST({ version: '10' }).setToken(TOKEN);

// ---------- UTILITIES ----------
const DEFAULT_PREFIX = '`';
function getPrefix(userId) { return prefixes[userId] || DEFAULT_PREFIX; }
function ensureEconomy(uid) { if (!economy[uid]) economy[uid] = { balance: 0, lastDaily: 0 }; }
function ensureXP(uid) { if (!xp[uid]) xp[uid] = { xp: 0, level: 0, lastMessage: 0 }; }

function giveXP(uid) {
  ensureXP(uid);
  const now = Date.now();
  if (now - (xp[uid].lastMessage||0) < 30_000) return false;
  xp[uid].lastMessage = now;
  const gain = Math.floor(Math.random()*6)+5;
  xp[uid].xp += gain;
  const need = (xp[uid].level+1)*100;
  if (xp[uid].xp >= need) { xp[uid].xp -= need; xp[uid].level += 1; safeWrite(FILES.xp, xp); return true; }
  safeWrite(FILES.xp, xp);
  return false;
}

// cooldowns
const cooldowns = new Map();
function isOnCooldown(key, uid, ms=1000) {
  if (!cooldowns.has(key)) cooldowns.set(key, new Map());
  const m = cooldowns.get(key);
  const last = m.get(uid) || 0;
  if (Date.now() - last < ms) return true;
  m.set(uid, Date.now());
  setTimeout(()=> m.delete(uid), ms);
  return false;
}

// ---------- MUSIC (play-dl + @discordjs/voice) ----------
const players = new Map(); // guildId -> { player, resource, connection }
async function ensureQueue(guildId) {
  if (!musicQueues[guildId]) musicQueues[guildId] = { queue: [], playing: false, playCount: 0 };
}
async function playNext(guildId) {
  await ensureQueue(guildId);
  const q = musicQueues[guildId];
  if (!q.queue.length) { q.playing = false; safeWrite(FILES.musicQueues, musicQueues); return false; }
  const item = q.queue.shift();
  const conn = getVoiceConnection(guildId);
  if (!conn) { q.queue.unshift(item); q.playing = false; safeWrite(FILES.musicQueues, musicQueues); return false; }
  const stream = await playdl.stream(item.url).catch(()=>null);
  if (!stream) {
    // skip
    return playNext(guildId);
  }
  const resource = createAudioResource(stream.stream, { inputType: stream.type });
  let state = players.get(guildId);
  if (!state) {
    const player = createAudioPlayer();
    conn.subscribe(player);
    state = { player, resource: null, connection: conn };
    players.set(guildId, state);
    player.on(AudioPlayerStatus.Idle, () => { playNext(guildId); });
    player.on('error', (err) => { console.error('Audio player error', err); playNext(guildId); });
  }
  state.player.play(resource);
  q.playing = true;
  q.playCount = (q.playCount||0)+1;
  safeWrite(FILES.musicQueues, musicQueues);
  return true;
}

// ---------- COMMAND REGISTRATION ----------
function buildSlashCommands() {
  const base = [
    new SlashCommandBuilder().setName('help').setDescription('Show help & invite'),
    new SlashCommandBuilder().setName('ping').setDescription('Check latency'),
    new SlashCommandBuilder().setName('hi').setDescription('Say hi back'),
    new SlashCommandBuilder().setName('commands').setDescription('List commands & categories'),
    new SlashCommandBuilder().setName('balance').setDescription('Show your balance'),
    new SlashCommandBuilder().setName('daily').setDescription('Claim daily reward'),
    // moderation
    new SlashCommandBuilder().setName('kick').setDescription('Kick a member (role-bound)').addUserOption(o=>o.setName('user').setDescription('Member').setRequired(true)).addStringOption(o=>o.setName('reason').setDescription('Reason')),
    new SlashCommandBuilder().setName('ban').setDescription('Ban a member (role-bound)').addUserOption(o=>o.setName('user').setDescription('Member').setRequired(true)).addStringOption(o=>o.setName('reason').setDescription('Reason')),
    new SlashCommandBuilder().setName('timeout').setDescription('Timeout member (role-bound)').addUserOption(o=>o.setName('user').setDescription('Member').setRequired(true)).addIntegerOption(o=>o.setName('seconds').setDescription('Seconds').setRequired(true)),
    new SlashCommandBuilder().setName('purge').setDescription('Bulk delete messages (role-bound)').addIntegerOption(o=>o.setName('amount').setDescription('Amount').setRequired(true)),
    // role binding / logs / setup
    new SlashCommandBuilder().setName('bind').setDescription('Bind a staff role (owner only)').addStringOption(o=>o.setName('type').setDescription('what to bind, e.g. staff').setRequired(true)).addRoleOption(o=>o.setName('role').setDescription('Role to bind').setRequired(true)),
    new SlashCommandBuilder().setName('setlogchannel').setDescription('Set moderation log channel (owner only)').addChannelOption(o=>o.setName('channel').setDescription('Log channel').setRequired(true)),
    // automation
    new SlashCommandBuilder().setName('autorespond-add').setDescription('Add autoresponder (owner) ').addStringOption(o=>o.setName('trigger').setDescription('Trigger').setRequired(true)).addStringOption(o=>o.setName('response').setDescription('Response').setRequired(true)),
    new SlashCommandBuilder().setName('autorespond-remove').setDescription('Remove autoresponder (owner) ').addStringOption(o=>o.setName('trigger').setDescription('Trigger').setRequired(true)),
    // aliases
    new SlashCommandBuilder().setName('alias-add').setDescription('Add alias (owner)').addStringOption(o=>o.setName('alias').setDescription('alias').setRequired(true)).addStringOption(o=>o.setName('target').setDescription('target command').setRequired(true)),
    new SlashCommandBuilder().setName('alias-remove').setDescription('Remove alias (owner)').addStringOption(o=>o.setName('alias').setDescription('alias').setRequired(true)),
    // starboard / welcome / voice
    new SlashCommandBuilder().setName('starboard-setup').setDescription('Set starboard channel (owner)').addChannelOption(o=>o.setName('channel').setDescription('text channel').setRequired(true)).addIntegerOption(o=>o.setName('threshold').setDescription('stars threshold')),
    new SlashCommandBuilder().setName('welcome-setup').setDescription('Set welcome channel (owner)').addChannelOption(o=>o.setName('channel').setDescription('text channel').setRequired(true)).addStringOption(o=>o.setName('message').setDescription('welcome message')),
    new SlashCommandBuilder().setName('voice-lobby-set').setDescription('Set lobby for join-to-create (owner)').addChannelOption(o=>o.setName('channel').setDescription('voice lobby').setRequired(true)).addChannelOption(o=>o.setName('category').setDescription('category for temp rooms')),
    new SlashCommandBuilder().setName('snipe').setDescription('Show last deleted message (channel)'),
    // music controls
    new SlashCommandBuilder().setName('play').setDescription('Play music (YouTube/Spotify/SoundCloud) ').addStringOption(o=>o.setName('query').setDescription('URL or search query').setRequired(true)),
    new SlashCommandBuilder().setName('skip').setDescription('Skip current track'),
    new SlashCommandBuilder().setName('stop').setDescription('Stop playback & clear queue'),
    new SlashCommandBuilder().setName('queue').setDescription('Show queue'),
    // custom commands admin
    new SlashCommandBuilder().setName('addcommand').setDescription('Add custom command (owner)').addStringOption(o=>o.setName('name').setDescription('name').setRequired(true)).addStringOption(o=>o.setName('response').setDescription('response').setRequired(true)),
    new SlashCommandBuilder().setName('removecommand').setDescription('Remove custom command (owner)').addStringOption(o=>o.setName('name').setDescription('name').setRequired(true))
  ];
  // dynamic custom commands added to commands list already (but don't add slash inputs for unsafe names)
  for (const [n, r] of Object.entries(customCommands || {})) {
    if (/^[\w-]{1,32}$/.test(n)) {
      try { base.push(new SlashCommandBuilder().setName(n).setDescription(typeof r === 'string' ? r.slice(0,100) : 'custom command').toJSON()); }
      catch {}
    }
  }
  return base.map(c => (c.toJSON ? c.toJSON() : c));
}

async function registerAllSlashCommands() {
  try {
    console.log('Registering global slash commands...');
    const list = buildSlashCommands();
    await rest.put(Routes.applicationCommands(CLIENT_ID), { body: list });
    console.log('Commands registered (global). Allow a few minutes to propagate.');
  } catch (e) { console.error('registerAllSlashCommands error', e); }
}

// ---------- EVENT: capture deleted messages (snipe) ----------
client.on('messageDelete', (msg) => {
  try {
    if (!msg) return;
    snipeStore[msg.channelId] = {
      content: msg.content || null,
      authorTag: msg.author ? msg.author.tag : 'Unknown',
      authorId: msg.author ? msg.author.id : null,
      attachments: msg.attachments ? msg.attachments.map(a => a.url) : [],
      timestamp: Date.now()
    };
    safeWrite(FILES.snipe, snipeStore);
    // log deletion if configured
    const lc = logChannels[msg.guildId];
    if (lc) {
      const ch = msg.guild?.channels.cache.get(lc);
      if (ch) {
        ch.send({ embeds: [ new EmbedBuilder().setTitle('Message Deleted').addFields(
          { name: 'Channel', value: `${msg.channel}` },
          { name: 'Author', value: `${msg.author?.tag || 'unknown'}` },
          { name: 'Content', value: msg.content ? (msg.content.slice(0,1000)) : '[no text]' }
        ).setTimestamp() ] }).catch(()=>{});
      }
    }
  } catch (e) { console.error('snipe store error', e); }
});

// ---------- EVENT: reaction -> starboard ----------
client.on('messageReactionAdd', async (reaction, user) => {
  try {
    if (reaction.partial) await reaction.fetch();
    const msg = reaction.message;
    if (!msg.guild) return;
    const cfg = starboardCfg[msg.guild.id] || {};
    const threshold = cfg.threshold || 3;
    const sbChannelId = cfg.channelId;
    if (!sbChannelId) return;
    if (reaction.emoji.name !== '⭐') return;
    const count = msg.reactions.cache.get('⭐')?.count || 0;
    if (count < threshold) return;
    const sbChan = msg.guild.channels.cache.get(sbChannelId);
    if (!sbChan) return;
    // prevent duplicates: store posted starboard message ids in starboardCfg
    starboardCfg[msg.guild.id] = starboardCfg[msg.guild.id] || { channelId: sbChannelId, threshold };
    starboardCfg[msg.guild.id].posted = starboardCfg[msg.guild.id].posted || {};
    if (starboardCfg[msg.guild.id].posted[msg.id]) return;
    // post embed
    const embed = new EmbedBuilder().setAuthor({ name: msg.author.tag, iconURL: msg.author.displayAvatarURL() }).setDescription(msg.content || '[embed]').setFooter({ text: `⭐ ${count}` }).setTimestamp(msg.createdAt);
    await sbChan.send({ content: msg.url, embeds: [embed] }).catch(()=>{});
    starboardCfg[msg.guild.id].posted[msg.id] = true;
    safeWrite(FILES.starboard, starboardCfg);
  } catch (e) { console.error('starboard error', e); }
});

// ---------- EVENT: welcome/goodbye ----------
client.on('guildMemberAdd', member => {
  try {
    const cfg = welcomeCfg[member.guild.id];
    if (!cfg) return;
    const ch = member.guild.channels.cache.get(cfg.channelId);
    if (!ch) return;
    const msg = (cfg.message || 'Welcome {user} to {server}!').replace('{user}', `<@${member.id}>`).replace('{server}', member.guild.name);
    ch.send({ content: msg }).catch(()=>{});
  } catch (e) { console.error('welcome error', e); }
});
client.on('guildMemberRemove', member => {
  try {
    const cfg = welcomeCfg[member.guild.id];
    if (!cfg) return;
    const ch = member.guild.channels.cache.get(cfg.goodbyeChannelId || cfg.channelId);
    if (!ch) return;
    const msg = (cfg.goodbyeMessage || '{user} left {server}.').replace('{user}', `${member.user.tag}`).replace('{server}', member.guild.name);
    ch.send({ content: msg }).catch(()=>{});
  } catch (e) { console.error('goodbye error', e); }
});

// ---------- EVENT: role/channel changes & logging ----------
client.on('roleCreate', role => {
  try { const lc = logChannels[role.guild.id]; if (!lc) return; const ch = role.guild.channels.cache.get(lc); if (ch) ch.send({ embeds: [ new EmbedBuilder().setTitle('Role Created').addFields({name:'Role', value:role.name}).setTimestamp() ] }).catch(()=>{}); } catch(e){console.error(e);}
});
client.on('roleDelete', role => {
  try { const lc = logChannels[role.guild.id]; if (!lc) return; const ch = role.guild.channels.cache.get(lc); if (ch) ch.send({ embeds: [ new EmbedBuilder().setTitle('Role Deleted').addFields({name:'Role', value:role.name}).setTimestamp() ] }).catch(()=>{}); } catch(e){console.error(e);}
});
client.on('channelCreate', channel => {
  try { const lc = logChannels[channel.guildId]; if (!lc) return; const ch = channel.guild.channels.cache.get(lc); if (ch) ch.send({ embeds: [ new EmbedBuilder().setTitle('Channel Created').addFields({name:'Channel', value:channel.name}).setTimestamp() ] }).catch(()=>{}); } catch(e){console.error(e);}
});
client.on('channelDelete', channel => {
  try { const lc = logChannels[channel.guildId]; if (!lc) return; const ch = channel.guild.channels.cache.get(lc); if (ch) ch.send({ embeds: [ new EmbedBuilder().setTitle('Channel Deleted').addFields({name:'Channel', value:channel.name}).setTimestamp() ] }).catch(()=>{}); } catch(e){console.error(e);}
});

// ---------- VOICE MASTER: join-to-create ----------
const TEMP_VOICES = new Map(); // channelId -> ownerId
client.on('voiceStateUpdate', async (oldState, newState) => {
  try {
    const g = newState.guild || oldState.guild;
    if (!g) return;
    const cfg = voiceCfg[g.id];
    if (!cfg || !cfg.lobbyChannelId) return;
    const lobby = cfg.lobbyChannelId;

    // joined lobby
    if (newState.channelId === lobby && oldState.channelId !== lobby) {
      // create temp
      const owner = newState.member;
      const name = `${cfg.prefixName || 'Room'} • ${owner.user.username}`;
      const created = await g.channels.create({ name, type: 2, parent: cfg.tmpCategoryId || undefined }).catch(()=>null);
      if (!created) return;
      TEMP_VOICES.set(created.id, owner.id);
      // move user
      try { await newState.setChannel(created); } catch {}
      // delete when empty
      const timeoutCheck = setInterval(() => {
        const ch = g.channels.cache.get(created.id);
        if (!ch || ch.members.size === 0) {
          try { ch?.delete().catch(()=>{}); } catch {}
          TEMP_VOICES.delete(created.id);
          clearInterval(timeoutCheck);
        }
      }, 20_000);
    }

    // if left a temp channel and empty => schedule delete handled above
  } catch (e) { console.error('voiceStateUpdate error', e); }
});

// ---------- INTERACTION (slash) handler ----------
client.on('interactionCreate', async (interaction) => {
  try {
    if (!interaction.isChatInputCommand()) return;
    const cmd = interaction.commandName;
    const uid = interaction.user.id;
    const isOwner = uid === OWNER_ID;

    // allow only listed users except commands list or owner
    if (cmd !== 'commands' && !allowedUsers.has(uid) && !isOwner) {
      return interaction.reply({ content: '❌ You are not allowed to use this bot. Ask owner to /allow you.', ephemeral: true });
    }
    if (isOnCooldown(cmd, uid, 1200)) return interaction.reply({ content: '⏳ Slow down.', ephemeral: true });

    // core
    if (cmd === 'help') return interaction.reply('yooo, join up papi https://discord.gg/min');
    if (cmd === 'ping') return interaction.reply(`🏓 ${client.ws.ping}ms`);
    if (cmd === 'hi') return interaction.reply(`${interaction.user} hi!`);

    // commands list -> embed with categories (reload file)
    if (cmd === 'commands') {
      commandsList = safeRead(FILES.commandsList, commandsList);
      const embed = new EmbedBuilder().setTitle('📜 Commands').setColor(0x5865F2).setDescription('Slash and prefix commands (prefix default: `)');
      for (const [cat, entries] of Object.entries(commandsList || {})) {
        const lines = Object.entries(entries || {}).map(([n,d]) => `• \`/${n}\` — ${d}`);
        if (lines.length) embed.addFields({ name: cat, value: lines.join('\n').slice(0,1024) });
      }
      const custom = Object.keys(customCommands || {});
      if (custom.length) embed.addFields({ name: 'Custom', value: custom.map(c => `• \`/${c}\``).join(', ').slice(0,1024) });
      return interaction.reply({ embeds: [embed] });
    }

    // economy
    if (cmd === 'balance') { ensureEconomy(uid); return interaction.reply({ content: `💰 ${interaction.user.tag} — ${economy[uid].balance}` }); }
    if (cmd === 'daily') {
      ensureEconomy(uid);
      const now = Date.now(); const one = 24*60*60*1000; const last = economy[uid].lastDaily || 0;
      if (now - last < one) return interaction.reply({ content: `You already claimed daily. Try in ${prettyMs(one - (now-last))}.`, ephemeral: true });
      const amount = 100 + Math.floor(Math.random()*100); economy[uid].balance += amount; economy[uid].lastDaily = now; safeWrite(FILES.economy, economy);
      return interaction.reply({ content: `✅ You claimed ${amount} coins!` });
    }

    // moderation: role-bound (owner overrides)
    if (['kick','ban','purge','timeout','mute'].includes(cmd)) {
      if (!interaction.guild) return interaction.reply({ content: 'Use in a server.', ephemeral: true });
      const guildId = interaction.guildId;
      const staffRoleId = (roleBindings[guildId] && roleBindings[guildId].staff) || null;
      // owner allowed
      if (!isOwner) {
        // user must have bound role
        const member = await interaction.guild.members.fetch(uid).catch(()=>null);
        if (!member) return interaction.reply({ content: 'Member not found.', ephemeral: true });
        if (!staffRoleId || !member.roles.cache.has(staffRoleId)) return interaction.reply({ content: 'You do not have permission (bind a staff role first).', ephemeral: true });
      }
      // implement each
      if (cmd === 'kick') {
        const target = interaction.options.getUser('user');
        const reason = interaction.options.getString('reason') || 'No reason';
        const res = await (async () => { try { await interaction.guild.members.kick(target.id, reason); return { ok: true }; } catch (e) { return { ok: false, reason: e.message }; } })();
        if (res.ok) {
          // log
          const lc = logChannels[interaction.guildId]; if (lc) { const ch = interaction.guild.channels.cache.get(lc); ch?.send({ embeds: [new EmbedBuilder().setTitle('Member Kicked').addFields({name:'User', value:`${target.tag}`},{name:'By', value:`${interaction.user.tag}`},{name:'Reason', value:reason}).setTimestamp()] }).catch(()=>{}); }
          return interaction.reply({ content: `✅ Kicked ${target.tag}` });
        } else return interaction.reply({ content: `❌ ${res.reason}`, ephemeral: true });
      }
      if (cmd === 'ban') {
        const target = interaction.options.getUser('user'); const reason = interaction.options.getString('reason') || 'No reason';
        const res = await (async ()=>{ try{ await interaction.guild.members.ban(target.id, { reason }); return {ok:true}; }catch(e){return{ok:false,reason:e.message}} })();
        if (res.ok) { const lc = logChannels[interaction.guildId]; if (lc){ const ch=interaction.guild.channels.cache.get(lc); ch?.send({ embeds:[ new EmbedBuilder().setTitle('Member Banned').addFields({name:'User',value:target.tag},{name:'By',value:interaction.user.tag},{name:'Reason',value:reason}).setTimestamp() ] }).catch(()=>{}); } return interaction.reply({ content:`✅ Banned ${target.tag}` }); }
        return interaction.reply({ content:`❌ ${res.reason}`, ephemeral:true });
      }
      if (cmd === 'purge') {
        const amount = Math.min(100, Math.max(1, interaction.options.getInteger('amount') || 5));
        const fetched = await interaction.channel.messages.fetch({ limit: amount }).catch(()=>null);
        if (!fetched) return interaction.reply({ content:'Failed to fetch messages', ephemeral:true });
        await interaction.channel.bulkDelete(fetched, true).catch(()=>{});
        const lc = logChannels[interaction.guildId]; if (lc){ const ch = interaction.guild.channels.cache.get(lc); ch?.send({ embeds:[ new EmbedBuilder().setTitle('Messages Purged').addFields({name:'By',value:interaction.user.tag},{name:'Count',value:`${fetched.size}`}).setTimestamp()] }).catch(()=>{}); }
        return interaction.reply({ content:`✅ Deleted ${fetched.size} messages.`, ephemeral:true });
      }
      if (cmd === 'timeout' || cmd === 'mute') {
        const target = interaction.options.getUser('user'); const seconds = interaction.options.getInteger('seconds') || 60;
        const member = await interaction.guild.members.fetch(target.id).catch(()=>null);
        if (!member) return interaction.reply({ content:'Member not found', ephemeral:true });
        await member.timeout(seconds*1000, `Timed out by ${interaction.user.tag}`).catch(()=>{});
        const lc = logChannels[interaction.guildId]; if (lc){ const ch=interaction.guild.channels.cache.get(lc); ch?.send({ embeds:[ new EmbedBuilder().setTitle('Member Timed Out').addFields({name:'User',value:target.tag},{name:'By',value:interaction.user.tag},{name:'Duration',value:`${seconds}s`}).setTimestamp()] }).catch(()=>{}); }
        return interaction.reply({ content:`✅ Timed out ${target.tag} for ${seconds}s` });
      }
    }

    // bind staff role (owner only)
    if (cmd === 'bind') {
      if (! (uid === OWNER_ID) ) return interaction.reply({ content:'Owner only.', ephemeral:true });
      const type = interaction.options.getString('type');
      const role = interaction.options.getRole('role');
      if (!role) return interaction.reply({ content:'Role missing', ephemeral:true });
      roleBindings[interaction.guildId] = roleBindings[interaction.guildId] || {};
      roleBindings[interaction.guildId][type] = role.id;
      safeWrite(FILES.roles, roleBindings);
      return interaction.reply({ content:`✅ Bound ${type} -> <@&${role.id}>`, ephemeral:true });
    }

    // set log channel
    if (cmd === 'setlogchannel') {
      if (!(uid === OWNER_ID)) return interaction.reply({ content:'Owner only.', ephemeral:true });
      const ch = interaction.options.getChannel('channel');
      if (!ch || ch.type !== 0) return interaction.reply({ content:'Pick a text channel.', ephemeral:true });
      logChannels[interaction.guildId] = ch.id;
      safeWrite(FILES.logs, logChannels);
      return interaction.reply({ content:`✅ Logs will go to ${ch}`, ephemeral:true });
    }

    // autorespond add/remove
    if (cmd === 'autorespond-add') {
      if (! (uid === OWNER_ID) ) return interaction.reply({ content:'Owner only.', ephemeral:true });
      const trigger = interaction.options.getString('trigger').toLowerCase();
      const resp = interaction.options.getString('response');
      const g = interaction.guildId || 'dm';
      autoresponders[g] = autoresponders[g] || {};
      autoresponders[g][trigger] = resp;
      safeWrite(FILES.autoresponders, autoresponders);
      return interaction.reply({ content:`✅ Added autoresponder for "${trigger}"`, ephemeral:true });
    }
    if (cmd === 'autorespond-remove') {
      if (! (uid === OWNER_ID) ) return interaction.reply({ content:'Owner only.', ephemeral:true });
      const trigger = interaction.options.getString('trigger').toLowerCase();
      const g = interaction.guildId || 'dm';
      if (autoresponders[g] && autoresponders[g][trigger]) { delete autoresponders[g][trigger]; safeWrite(FILES.autoresponders, autoresponders); return interaction.reply({ content:'✅ Removed', ephemeral:true }); }
      return interaction.reply({ content:'Not found', ephemeral:true });
    }

    // aliases
    if (cmd === 'alias-add') {
      if (!(uid === OWNER_ID)) return interaction.reply({ content:'Owner only.', ephemeral:true });
      const al = interaction.options.getString('alias').toLowerCase();
      const target = interaction.options.getString('target').toLowerCase();
      const g = interaction.guildId || 'dm';
      aliases[g] = aliases[g] || {};
      aliases[g][al] = target;
      safeWrite(FILES.aliases, aliases);
      return interaction.reply({ content:`✅ Alias ${al} -> ${target}`, ephemeral:true });
    }
    if (cmd === 'alias-remove') {
      if (!(uid === OWNER_ID)) return interaction.reply({ content:'Owner only.', ephemeral:true });
      const al = interaction.options.getString('alias').toLowerCase();
      const g = interaction.guildId || 'dm';
      if (aliases[g] && aliases[g][al]) { delete aliases[g][al]; safeWrite(FILES.aliases, aliases); return interaction.reply({ content:'✅ Removed', ephemeral:true }); }
      return interaction.reply({ content:'Not found', ephemeral:true });
    }

    // starboard setup
    if (cmd === 'starboard-setup') {
      if (!(uid === OWNER_ID)) return interaction.reply({ content:'Owner only.', ephemeral:true });
      const ch = interaction.options.getChannel('channel'); const thresh = interaction.options.getInteger('threshold') || 3;
      if (!ch || ch.type !== 0) return interaction.reply({ content:'Pick a text channel.', ephemeral:true });
      starboardCfg[interaction.guildId] = { channelId: ch.id, threshold: thresh, posted: starboardCfg[interaction.guildId]?.posted || {} };
      safeWrite(FILES.starboard, starboardCfg);
      return interaction.reply({ content:`✅ Starboard set to ${ch} threshold=${thresh}`, ephemeral:true });
    }

    // welcome setup
    if (cmd === 'welcome-setup') {
      if (!(uid === OWNER_ID)) return interaction.reply({ content:'Owner only.', ephemeral:true });
      const ch = interaction.options.getChannel('channel'); const msg = interaction.options.getString('message') || null;
      if (!ch || ch.type !== 0) return interaction.reply({ content:'Pick a text channel.', ephemeral:true });
      welcomeCfg[interaction.guildId] = { channelId: ch.id, message: msg };
      safeWrite(FILES.welcome, welcomeCfg);
      return interaction.reply({ content:`✅ Welcome set to ${ch}`, ephemeral:true });
    }

    // voice lobby set
    if (cmd === 'voice-lobby-set') {
      if (!(uid === OWNER_ID)) return interaction.reply({ content:'Owner only.', ephemeral:true });
      const lobby = interaction.options.getChannel('channel'); const category = interaction.options.getChannel('category');
      if (!lobby || lobby.type !== 2) return interaction.reply({ content:'Pick a voice channel for lobby.', ephemeral:true });
      voiceCfg[interaction.guildId] = { lobbyChannelId: lobby.id, tmpCategoryId: category?.id || null, prefixName: 'Room' };
      safeWrite(FILES.voice, voiceCfg);
      return interaction.reply({ content:`✅ Voice lobby set to ${lobby.name}`, ephemeral:true });
    }

    // snipe
    if (cmd === 'snipe') {
      const data = snipeStore[interaction.channelId];
      if (!data) return interaction.reply({ content: 'No sniped message found.', ephemeral: true });
      const text = `**${data.authorTag}**: ${data.content || '[no content]'}\n${(data.attachments||[]).join('\n')}`;
      return interaction.reply({ content: text, ephemeral: true });
    }

    // music: play/skip/stop/queue
    if (cmd === 'play') {
      const query = interaction.options.getString('query');
      // require user in voice
      const member = interaction.member;
      const guildId = interaction.guildId;
      if (!member.voice.channel) return interaction.reply({ content: 'You must be in a voice channel to use music.', ephemeral: true });
      // resolve URL or search
      let info;
      try {
        if (playdl.yt_validate(query) === 'video') info = await playdl.video_info(query);
        else if (await playdl.sp_validate(query)) { // spotify or other
          const sp = await playdl.search(query, { source: { spotify: 'track,playlist' } }).catch(()=>null);
          if (sp && sp.length) info = sp[0];
          else info = await playdl.search(query, { limit: 1 }).catch(()=>null);
        } else {
          // search on YouTube
          const search = await playdl.search(query, { source: { youtube: 'video' }, limit: 1 }).catch(()=>null);
          info = search && search.length ? search[0] : null;
        }
      } catch (e) { info = null; }
      // fallback: if query is plain URL and playdl.stream supports it, push
      const url = (info && info.url) ? info.url : query;
      await ensureQueue(interaction.guildId);
      musicQueues[guildId].queue.push({ title: (info && info.title) ? info.title : query, url });
      safeWrite(FILES.musicQueues, musicQueues);
      // join voice
      try {
        const conn = joinVoiceChannel({ channelId: member.voice.channel.id, guildId: interaction.guildId, adapterCreator: interaction.guild.voiceAdapterCreator });
        // if not playing, start
        if (!musicQueues[guildId].playing) setTimeout(()=> playNext(guildId), 1000);
      } catch (e) { console.error('join voice error', e); }
      return interaction.reply({ content: `✅ Queued: ${info?.title || url}` });
    }
    if (cmd === 'skip') {
      const conn = getVoiceConnection(interaction.guildId);
      if (!conn) return interaction.reply({ content: 'Nothing playing.', ephemeral: true });
      const st = players.get(interaction.guildId);
      if (st && st.player) st.player.stop();
      return interaction.reply({ content: '⏭ Skipped.' });
    }
    if (cmd === 'stop') {
      const conn = getVoiceConnection(interaction.guildId);
      if (conn) { conn.destroy(); players.delete(interaction.guildId); musicQueues[interaction.guildId] = { queue: [], playing: false, playCount: 0 }; safeWrite(FILES.musicQueues, musicQueues); }
      return interaction.reply({ content: '⏹ Stopped and cleared queue.' });
    }
    if (cmd === 'queue') {
      await ensureQueue(interaction.guildId);
      const q = musicQueues[interaction.guildId];
      if (!q.queue.length) return interaction.reply({ content: 'Queue empty.', ephemeral: true });
      const list = q.queue.slice(0,10).map((it,i)=>`${i+1}. ${it.title}`).join('\n');
      return interaction.reply({ content: `Queue:\n${list}` });
    }

    // custom commands admin
    if (cmd === 'addcommand') {
      if (!(uid === OWNER_ID)) return interaction.reply({ content:'Owner only.', ephemeral:true });
      const name = interaction.options.getString('name').toLowerCase();
      const resp = interaction.options.getString('response');
      if (!/^[\w-]{1,32}$/.test(name)) return interaction.reply({ content: 'Invalid command name.', ephemeral: true });
      customCommands[name] = resp;
      safeWrite(FILES.commands, customCommands);
      await registerAllSlashCommands();
      return interaction.reply({ content: `✅ Added /${name}`, ephemeral:true });
    }
    if (cmd === 'removecommand') {
      if (!(uid === OWNER_ID)) return interaction.reply({ content:'Owner only.', ephemeral:true });
      const name = interaction.options.getString('name').toLowerCase();
      if (!customCommands[name]) return interaction.reply({ content:'Not found', ephemeral:true });
      delete customCommands[name];
      safeWrite(FILES.commands, customCommands);
      await registerAllSlashCommands();
      return interaction.reply({ content:`✅ Removed /${name}`, ephemeral:true });
    }

    // runtime custom commands
    if (customCommands[cmd]) return interaction.reply({ content: String(customCommands[cmd]).slice(0,1900) });

    return interaction.reply({ content: 'Unknown command or not implemented.', ephemeral: true });

  } catch (e) {
    console.error('interaction handler error', e);
    if (!interaction.replied) interaction.reply({ content: 'Internal error', ephemeral: true }).catch(()=>{});
  }
});

// ---------- MESSAGE handler (prefix + automation) ----------
client.on('messageCreate', async (message) => {
  try {
    if (message.author.bot) return;

    // autoresponders for guild
    const g = message.guildId || 'dm';
    const lower = message.content.toLowerCase();
    if (autoresponders[g]) {
      for (const [trigger, resp] of Object.entries(autoresponders[g])) {
        if (lower.includes(trigger)) {
          await message.channel.send({ content: resp.replace('{user}', `<@${message.author.id}>`) }).catch(()=>{});
        }
      }
    }

    // alias exact match
    const aliasMap = aliases[g] || {};
    const trimmed = lower.trim();
    if (aliasMap[trimmed]) {
      const target = aliasMap[trimmed];
      if (customCommands[target]) { message.channel.send(String(customCommands[target]).slice(0,1900)).catch(()=>{}); return; }
    }

    // snipe / xp
    const leveled = giveXP(message.author.id);
    if (leveled) message.channel.send(`${message.author}, you leveled up! 🎉`).catch(()=>{});

    // prefix handling
    const pref = getPrefix(message.author.id);
    if (!message.content.startsWith(pref)) return;
    const body = message.content.slice(pref.length).trim();
    if (!body) return;
    const parts = body.split(/\s+/);
    const invoked = parts.shift().toLowerCase();

    // permission guard
    if (invoked !== 'commands' && !allowedUsers.has(message.author.id) && message.author.id !== OWNER_ID) {
      return message.reply('❌ You are not allowed to use this bot. Ask owner to /allow you.').catch(()=>{});
    }
    if (isOnCooldown(`prefix_${invoked}`, message.author.id, 800)) return message.reply('⏳ Slow down.').catch(()=>{});

    // alias lookup
    const alias = (aliases[g] && aliases[g][invoked]) || null;
    const cmd = alias || invoked;

    // built-ins
    if (cmd === 'ping') return message.reply(`🏓 ${client.ws.ping}ms`).catch(()=>{});
    if (cmd === 'hi') return message.reply(`${message.author} hi!`).catch(()=>{});
    if (cmd === 'help') return message.reply('yooo, join up papi https://discord.gg/min').catch(()=>{});
    if (cmd === 'balance') { ensureEconomy(message.author.id); return message.reply(`💰 ${message.author.tag} — ${economy[message.author.id].balance}`).catch(()=>{}); }
    if (cmd === 'daily') {
      ensureEconomy(message.author.id);
      const now = Date.now(), one = 24*60*60*1000, last = economy[message.author.id].lastDaily || 0;
      if (now - last < one) return message.reply(`You already claimed daily. Try in ${prettyMs(one - (now-last))}`).catch(()=>{});
      const amt = 100 + Math.floor(Math.random()*100);
      economy[message.author.id].balance += amt; economy[message.author.id].lastDaily = now; safeWrite(FILES.economy, economy);
      return message.reply(`✅ You got ${amt} coins!`).catch(()=>{});
    }

    if (cmd === 'commands') {
      let text = '📜 **Available Commands**\n\n';
      for (const [cat, entries] of Object.entries(commandsList || {})) {
        text += `**${cat}**\n` + Object.entries(entries || {}).map(([n,d]) => `${pref}${n} — ${d}`).join('\n') + '\n\n';
      }
      const custom = Object.keys(customCommands || {});
      if (custom.length) text += `**Custom**\n` + custom.map(c => `${pref}${c}`).join(', ');
      return message.reply(text.slice(0,1900)).catch(()=>{});
    }

    if (cmd === 'snipe') {
      const data = snipeStore[message.channelId];
      if (!data) return message.reply('No sniped message.').catch(()=>{});
      return message.reply(`**${data.authorTag}**: ${data.content || '[no content]'}\n${(data.attachments||[]).join('\n')}`).catch(()=>{});
    }

    // custom prefix commands
    if (customCommands[cmd]) return message.reply(String(customCommands[cmd]).slice(0,1900)).catch(()=>{});

    // music prefix variants (play)
    if (cmd === 'play') {
      const query = parts.join(' ');
      if (!message.member.voice.channel) return message.reply('You must join voice to use music.').catch(()=>{});
      // similar logic as slash play - queue and join
      const guildId = message.guildId;
      let info = null;
      try {
        if (playdl.yt_validate(query) === 'video') info = await playdl.video_info(query);
        else { const s = await playdl.search(query, { limit: 1 }).catch(()=>null); info = s && s.length ? s[0] : null; }
      } catch (e) { info = null; }
      const url = info?.url || query;
      await ensureQueue(guildId);
      musicQueues[guildId].queue.push({ title: info?.title || query, url });
      safeWrite(FILES.musicQueues, musicQueues);
      try { joinVoiceChannel({ channelId: message.member.voice.channel.id, guildId: guildId, adapterCreator: message.guild.voiceAdapterCreator }); } catch(e){}
      if (!musicQueues[guildId].playing) setTimeout(()=> playNext(guildId), 1000);
      return message.reply(`✅ Queued: ${info?.title || url}`).catch(()=>{});
    }

    return message.reply('Unknown command.').catch(()=>{});
  } catch (e) { console.error('messageCreate error', e); }
});

// ---------- STARTUP ----------
client.once('ready', async () => {
  console.log(`Logged in as ${client.user.tag}`);
  allowedUsers.add(OWNER_ID);
  safeWrite(FILES.allowed, [...allowedUsers]);
  // ensure commandsList exists
  if (!fs.existsSync(FILES.commandsList)) safeWrite(FILES.commandsList, commandsList);
  await registerAllSlashCommands();
  saveAll();
});
client.login(TOKEN);

// periodic saving
setInterval(saveAll, 30_000);

// global error handlers
process.on('unhandledRejection', e => console.error('UnhandledRejection', e));
process.on('uncaughtException', e => console.error('UncaughtException', e));